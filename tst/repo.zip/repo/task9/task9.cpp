#include <iostream>
#include <vector>

int main()
{
	std::vector<int> arr; // array of a numbers
	
	while (!std::cin.eof() && std::cin.peek() != '\n')
	{
		int n;
		std::cin >> n;
		arr.push_back(n);
	}
	
	int max_length = 0,
		max_sum = 0;
		
	
	int indx = 1, 		 // current position in the arr
		indx_start = 0,  // position of a current subsequence
		indx_max = -1;   // index of the longest rising subsequence
		
	//int last_elem = arr[0];
	
	int crnt_l = 1; 	 // length of a current subsequence
	int crnt_s = arr[0]; // sum of a numbers in a current subsequence
	
	// looking for longest and max subsequence
	for (; indx < arr.size(); ++indx)
	{
		if (arr[indx] <= arr[indx - 1])
		{
			if (crnt_l > max_length || (crnt_l == max_length && crnt_s >= max_sum))
			{
				max_length = crnt_l;
				max_sum    = crnt_s;
				indx_max   = indx_start;
			}
			
			crnt_l = crnt_s = 0;
			indx_start = indx;
		}
		
		crnt_l++;
		crnt_s += arr[indx];
	}
	
	// check for last subsequence
	if (crnt_l > max_length || (crnt_l == max_length && crnt_s >= max_sum))
	{
		max_length = crnt_l;
		max_sum    = crnt_s;
		indx_max   = indx_start;
	}
	
	// printing the longest and max subsequence
	for (int l = 0; l < max_length; ++l)
	{
		std::cout << arr[indx_max + l] << ' ';
	}
	
	std::cout << '\n';
}

