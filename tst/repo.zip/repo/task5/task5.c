#include <stdio.h>
#include <errno.h>
#include <fcntl.h>

int main()
{

	int fd = open("file", O_APPEND);
	if (fd == -1)
	{
		int tmp = errno;
		perror("Error");
		printf("Errno = %d\n", tmp);
		
		return tmp;
	}

	return 0;
}
