#include <stdio.h>
#include <sys/stat.h>
#include <time.h>

void print_file_type(mode_t mode)
{
	if (S_ISLNK(mode)) printf("symbolic link\n");
	else if(S_ISREG(mode)) printf("regular file\n");
	else if(S_ISDIR(mode)) printf("directory\n");
	else if(S_ISCHR(mode)) printf("character device\n");
	else if(S_ISBLK(mode)) printf("block device\n");
	else if(S_ISFIFO(mode)) printf("FIFO\n");
	else if(S_ISSOCK(mode)) printf("socket\n");
}

int main(int argc, char** argv)
{
	if (argc < 2) { return -1; }
	
	char* path = argv[1];
	
	struct stat st;
	
	if (stat(path, &st) == -1) { return -1; }
	
	printf("File: %s\n", path);
	printf("Size: %ld\n", st.st_size);
	printf("Blocks: %ld\n", st.st_blocks);
	print_file_type(st.st_mode);
	printf("Mode: %o\n", st.st_mode & 0777);
	printf("Uid: %d\n", st.st_uid);
	printf("Inode: %ld\n", st.st_ino);
	printf("Access: %s", ctime(&st.st_atime));
	printf("Modify: %s", ctime(&st.st_mtime));
	printf("Change: %s", ctime(&st.st_ctime));
}

