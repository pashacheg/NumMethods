#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>

#define MATRIX_SIZE 100

int A  [MATRIX_SIZE][MATRIX_SIZE];
int B_T[MATRIX_SIZE][MATRIX_SIZE]; // transposed matrix of the B
int C  [MATRIX_SIZE][MATRIX_SIZE]; // resulting matrix

// A * B = C

int A_i,   // i-th string of the A
	B_i,   // i-th column of the B
	A_B_j; // j-th column/string of the A/B
	

void sigfunc_signal(int sig)
{
	printf("\n%d\t%d\n", A_i + 1, A_B_j + 1); // A's iterators
	printf("%d\t%d\n", A_B_j + 1, B_i + 1);   // B's iterators
	printf("%d\t%d\n", A_i + 1, B_i + 1);	  // C's iterators
	
	signal(SIGINT, SIG_DFL);
}

struct sigaction sa;

void sigfunc_sigaction(int sig)
{
	printf("\n%d\t%d\n", A_i + 1, A_B_j + 1); // A's iterators
	printf("%d\t%d\n", A_B_j + 1, B_i + 1);   // B's iterators
	printf("%d\t%d\n", A_i + 1, B_i + 1);	  // C's iterators
	
	sa.sa_handler = SIG_DFL;
	sigaction(SIGINT, &sa, NULL);
}

int main(int argc, char** argv)
{	
	if (argc < 2) { return -1; }
	
	if (!strcmp("--signal", argv[1]))
	{
		signal(SIGINT, sigfunc_signal);		
	}	
	else if (!strcmp("--sigaction", argv[1]))
	{		
		sa.sa_handler = sigfunc_sigaction;
		
		sigaction(SIGINT, &sa, NULL);
	}
	else { return 1; }
	

	for (B_i = 0; B_i < MATRIX_SIZE; ++B_i)
	{
		for (A_i = 0; A_i < MATRIX_SIZE; ++A_i)
		{
			int S = 0;
			for (A_B_j = 0; A_B_j < MATRIX_SIZE; ++A_B_j)
			{
				S += A[A_i][A_B_j] * B_T[B_i][A_B_j];
				usleep(500000);
			}
			
			C[A_i][B_i] = S;
		}
	}
	
	
}

