#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define BUF_SIZE 1024

typedef struct
{
	void* left_node;
	void* right_node;
	char* str;
} list;

list* link_to_right(list* last_node, list* node) 
// links node to right pointer of the last_node. last_node must be the end of list
{
	if (!node) { return NULL; }
	
	if (!last_node) { return node; }
	
	for (; last_node->right_node; last_node = last_node->right_node);
	
	last_node->right_node = node;
	node->left_node = last_node;
	
	return node;
}

void rem_node(list* node) // removes node from list
{
	if (!node) { return; }

	if (node->left_node)
	{
		((list*)(node->left_node))->right_node = node->right_node;
	}
	
	if (node->right_node)
	{
		((list*)(node->right_node))->left_node = node->left_node;
	}
	
	free(node->str);
	free(node);
}

int main(int argc, char** argv)
{
	int mode = 0;
	if (argc < 4) { return -1; }
	else
	{
		char modes[4][10] = { "plain", "rplain", "lex", "rlex" };
		
		for (; mode < 4 && strcmp(argv[3], modes[mode]); ++mode);
		
		if (mode == 4)  { return -1; }
	}
	
	FILE *f1 = fopen(argv[1], "r"), // reading
		 *f2 = fopen(argv[2], "w"); // writing
	
	if (!f1 || !f2) { return -1; }
	
	list* l_ptr = NULL; // points to the end of a list
	int ch = 0; 		// checking for consistance of a visible symbols: 1- string consists visible symbol, 0- else
	
	unsigned int sz = 0; // counts a number of times when current string isn't fitted into limit of the BUF_SIZE
	
	l_ptr = calloc(1, sizeof(list));
	if (!l_ptr) { return -1; }
	
	l_ptr->str = malloc(BUF_SIZE);
	if (!l_ptr->str) { return -1; }
	
	int plus_buf = 0; // used if string's size is more then BUF_SIZE; 
					  // it points to where copy into l_ptr->str next part of a string
	
	// here we start reading strings from file f1
	while (fgets(l_ptr->str + plus_buf, BUF_SIZE, f1))
	{		
		int i = 0;
		for (; l_ptr->str[i + plus_buf]; ++i)
		{
			ch = ch || l_ptr->str[i + plus_buf] > 31;
		}
		
		if (i == (BUF_SIZE - 1) && l_ptr->str[i - 1 + plus_buf] != '\n')
		{
			sz++;
			
			l_ptr->str = realloc(l_ptr->str, (sz + 1) * BUF_SIZE);
			if (!l_ptr->str) { return -1; }
			
			plus_buf = sz * BUF_SIZE - sz;
			
			continue;
		}
		
		sz = 0;
		
		if (!ch)
		{
			list* node_to_rem = l_ptr;
			l_ptr = l_ptr->left_node;
			
			rem_node(node_to_rem);
		}
		
		ch = 0;
		
		plus_buf = sz * BUF_SIZE - sz;
		
		list* new_nd = calloc(1, sizeof(list));
		if (!new_nd) { return -1; }
		
		l_ptr = link_to_right(l_ptr, new_nd);
		
		l_ptr->str = realloc(l_ptr->str, (sz + 1) * BUF_SIZE);
		if (!l_ptr->str) { return -1; }
	}
	
	list* node_to_rem = l_ptr;
	l_ptr = l_ptr->left_node;
		
	rem_node(node_to_rem);
			
	// here we sort strings
	
	list* first_elem = NULL; // for writing into file in next part of the program
	int swapped; // checking if strings were swapped during sorting iteration
		do
		{
			swapped = 0;
			
			list* crnt = l_ptr;
			
			while(crnt->left_node)
			{
				list* next = crnt->left_node;
				
				
				switch (mode)
				{
					case 0: // plain mode
						if (strcmp(crnt->str, next->str) < 0)
						{
							char* tmp = crnt->str;
							crnt->str = next->str;
							next->str = tmp;
					
							swapped = 1;
						}
						break;
					case 1: // rplain mode
						if (strcmp(crnt->str, next->str) > 0)
						{
							char* tmp = crnt->str;
							crnt->str = next->str;
							next->str = tmp;
					
							swapped = 1;
						}
						break;
					case 2: // lex mode
						if (strcasecmp(crnt->str, next->str) < 0)
						{
							char* tmp = crnt->str;
							crnt->str = next->str;
							next->str = tmp;
					
							swapped = 1;
						}
						break;
					case 3: // rlex mode
						if (strcasecmp(crnt->str, next->str) > 0)
						{
							char* tmp = crnt->str;
							crnt->str = next->str;
							next->str = tmp;
					
							swapped = 1;
						}
						break;
				}
				
				
				crnt = next;
			}
			
			first_elem = crnt;
		} while (swapped);
	
	//here we writing sorted strings into file f2
	
	for (; first_elem; first_elem = first_elem->right_node)
	{
		fprintf(f2, "%s", first_elem->str);
		rem_node(first_elem->left_node);
	}
	
	rem_node(l_ptr);
	
	return 0;
}

